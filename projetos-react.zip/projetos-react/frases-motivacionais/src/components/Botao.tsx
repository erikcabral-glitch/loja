import type { ReactNode } from 'react'
interface BotaoProps { children: ReactNode; onClick: () => void; variante?: 'primario' | 'secundario' | 'perigo' }
export default function Botao({ children, onClick, variante = 'primario' }: BotaoProps) { return <button type="button" className={variante} onClick={onClick}>{children}</button> }
