interface CabecalhoProps { titulo: string; subtitulo: string }
export default function Cabecalho({ titulo, subtitulo }: CabecalhoProps) { return <header><span className="etiqueta">Uma pausa para inspirar</span><h1>{titulo}</h1><p>{subtitulo}</p></header> }
