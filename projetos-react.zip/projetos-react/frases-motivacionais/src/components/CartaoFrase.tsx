import type { Frase } from '../types'
interface CartaoFraseProps { frase: Frase; ehFavorita: boolean }
export default function CartaoFrase({ frase, ehFavorita }: CartaoFraseProps) { return <figure className="cartao">{ehFavorita && <span className="favorita">★ Nos seus favoritos</span>}<blockquote>“{frase.texto}”</blockquote><figcaption>— {frase.autor}</figcaption></figure> }
