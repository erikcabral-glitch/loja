import type { Frase } from '../types'
import Botao from './Botao'
interface ListaFavoritosProps { favoritos: Frase[]; onRemover: (id: number) => void }
export default function ListaFavoritos({ favoritos, onRemover }: ListaFavoritosProps) { return <section><h2>Suas frases favoritas ({favoritos.length})</h2>{favoritos.length === 0 ? <p>Salve uma frase para encontrá-la aqui.</p> : <ul>{favoritos.map(frase => <li key={frase.id}><div>{frase.texto}<small>— {frase.autor}</small></div><Botao variante="perigo" onClick={() => onRemover(frase.id)}>Remover</Botao></li>)}</ul>}</section> }
