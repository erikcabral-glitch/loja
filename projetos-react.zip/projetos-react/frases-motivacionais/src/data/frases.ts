import type { Frase } from '../types'
// Frases autorais de exemplo, sem atribuição a pessoas reais.
const frases: Frase[] = [
  {
    "id": 1,
    "texto": "Cada pequeno passo também é progresso.",
    "autor": "Inspiração diária"
  },
  {
    "id": 2,
    "texto": "Comece hoje com o que você tem.",
    "autor": "Inspiração diária"
  },
  {
    "id": 3,
    "texto": "A constância transforma esforço em resultado.",
    "autor": "Inspiração diária"
  },
  {
    "id": 4,
    "texto": "Aprender algo novo é abrir uma nova porta.",
    "autor": "Inspiração diária"
  },
  {
    "id": 5,
    "texto": "Respeite seu ritmo e continue caminhando.",
    "autor": "Inspiração diária"
  },
  {
    "id": 6,
    "texto": "Errar faz parte de aprender.",
    "autor": "Inspiração diária"
  },
  {
    "id": 7,
    "texto": "Seu próximo passo pode mudar o seu dia.",
    "autor": "Inspiração diária"
  },
  {
    "id": 8,
    "texto": "Celebre as pequenas conquistas.",
    "autor": "Inspiração diária"
  },
  {
    "id": 9,
    "texto": "A prática de hoje constrói a confiança de amanhã.",
    "autor": "Inspiração diária"
  },
  {
    "id": 10,
    "texto": "Você pode recomeçar quantas vezes precisar.",
    "autor": "Inspiração diária"
  }
]
export default frases
