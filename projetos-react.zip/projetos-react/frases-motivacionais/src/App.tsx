import { useEffect, useState } from 'react'
import frases from './data/frases'
import type { Frase } from './types'
import Cabecalho from './components/Cabecalho'
import CartaoFrase from './components/CartaoFrase'
import Botao from './components/Botao'
import ListaFavoritos from './components/ListaFavoritos'
const CHAVE = 'frases-motivacionais:favoritos'
// Escolhe a posicao
function sortearIndice(indiceAtual: number): number {
  if (frases.length < 2) return indiceAtual
  return (indiceAtual + 1 + Math.floor(Math.random() * (frases.length - 1))) % frases.length
}
function carregarFavoritos(): Frase[] {
  try {
    const valor: unknown = JSON.parse(localStorage.getItem(CHAVE) ?? '[]')
    if (!Array.isArray(valor)) return []
    return frases.filter(frase => valor.some(item => typeof item === 'object' && item !== null && 'id' in item && item.id === frase.id))
  } catch { return [] }
}
export default function App() {
  const [indice, setIndice] = useState(0)
  const [contador, setContador] = useState(0)
  const [favoritos, setFavoritos] = useState<Frase[]>(carregarFavoritos)
  const [aviso, setAviso] = useState('')
  const frase = frases[indice]
  const ehFavorita = favoritos.some(item => item.id === frase.id)
  useEffect(() => {
    try { localStorage.setItem(CHAVE, JSON.stringify(favoritos)); setAviso('') }
    catch { setAviso('Não foi possível salvar os favoritos neste navegador.') }
  }, [favoritos])
  function novaFrase() { setIndice(atual => sortearIndice(atual)); setContador(atual => atual + 1) }
  function removerFavorito(id: number) { setFavoritos(atuais => atuais.filter(item => item.id !== id)) }
  function alternarFavorito() {
    setFavoritos(atuais => atuais.some(item => item.id === frase.id) ? atuais.filter(item => item.id !== frase.id) : [...atuais, frase])
  }
  return <main className="container"><Cabecalho titulo="Frases Motivacionais" subtitulo="Uma dose diaria de inspiracao para seguir em frente." /><CartaoFrase frase={frase} ehFavorita={ehFavorita}/><div className="acoes"><Botao onClick={novaFrase}>Nova frase →</Botao><Botao variante="secundario" onClick={alternarFavorito}>{ehFavorita ? 'Remover dos favoritos' : '★ Favoritar'}</Botao></div><p aria-live="polite">Frases sorteadas: {contador}</p>{aviso && <p role="status">{aviso}</p>}<ListaFavoritos favoritos={favoritos} onRemover={removerFavorito}/><footer>React + TypeScript · Componentes, props, estado e efeitos.</footer></main>
}
