export interface ProdutoDados { id: number; nome: string; preco: number; foto: string }
