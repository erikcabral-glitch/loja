import { useState } from 'react'
import Produto from './components/Produto'
import produtos from './data/produtos'
import type { ProdutoDados } from './types'
// O App controla o carrinho e passa a funcao de compra aos cartoes.
export default function App() {
  const [carrinho, setCarrinho] = useState<ProdutoDados[]>([])
  const [mensagem, setMensagem] = useState('Escolha um produto para comecar.')
  const total = carrinho.reduce((soma, produto) => soma + produto.preco, 0)
  function comprar(produto: ProdutoDados) {
    setCarrinho(atuais => [...atuais, produto])
    setMensagem(`${produto.nome} adicionado ao carrinho!`)
  }
  return <main className="container"><header><span className="etiqueta">Selecao especial</span><h1>Produtos para o seu dia.</h1><p>Escolha seu favorito e adicione ao carrinho.</p></header><div className="grade">{produtos.map(produto => <Produto key={produto.id} produto={produto} onComprar={comprar}/>)}</div><section aria-label="Carrinho"><h2>Seu carrinho</h2><p className="aviso" role="status">{mensagem}</p><div className="resumo"><strong>Itens: {carrinho.length}</strong><strong>Total: {total.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}</strong>{carrinho.length > 0 && <button type="button" className="secundario" onClick={() => {setCarrinho([]); setMensagem('Carrinho esvaziado.')}}>Limpar carrinho</button>}</div></section><footer>Aplicação didática · O botão Comprar adiciona itens ao carrinho. Não processa pagamentos.</footer></main>
}
