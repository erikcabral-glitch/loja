import type { ProdutoDados } from '../types'
interface ProdutoProps { produto: ProdutoDados; onComprar: (produto: ProdutoDados) => void }
// Componente reutilizável: recebe os dados e avisa o App quando há uma compra.
export default function Produto({ produto, onComprar }: ProdutoProps) {
  return <article className="produto"><img src={produto.foto} alt={produto.nome} width="600" height="450"/><div className="produto-info"><h2>{produto.nome}</h2><p className="preco">{produto.preco.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}</p><button type="button" onClick={() => onComprar(produto)} aria-label={`Comprar ${produto.nome}`}>Comprar</button></div></article>
}
