import type { ProdutoDados } from '../types'
const produtos: ProdutoDados[] = [{ id: 1, nome: 'Camera fotografica', preco: 1499.90, foto: './imagens/camera.jpg' }, { id: 2, nome: 'Tênis casual', preco: 249.90, foto: './imagens/tenis.jpg' }, { id: 3, nome: 'Relógio clássico', preco: 399.90, foto: './imagens/relogio.jpg' }]
export default produtos
