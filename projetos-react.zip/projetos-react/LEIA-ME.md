# Dois projetos independentes — React + TypeScript

## 1. Frases motivacionais
Implementação completa do roteiro da aula: 10 frases, componentes Cabecalho, CartaoFrase, Botao e ListaFavoritos, sorteio sem repetição imediata, contador, favoritos e persistência com localStorage. Arquivo principal: frases-motivacionais/src/App.tsx.

## 2. Loja de produtos
Aplicação separada com App.tsx e src/components/Produto.tsx. Cada cartão tem foto local, nome, preço em reais e botão Comprar. O App controla o carrinho, quantidade, total e limpeza. Compra demonstrativa, sem backend ou pagamento. As fotos estão em public/imagens e funcionam sem serviços externos durante o uso.

## Executar qualquer aplicação
Instale Node.js 22.12+ (recomendado: 24 LTS). Abra um terminal na pasta escolhida:

```bash
npm install
npm run dev
```

Abra o endereço mostrado no terminal. Para parar: Ctrl+C. Para rodar as duas ao mesmo tempo, use terminais separados; o Vite escolhe outra porta quando a primeira está ocupada.

## Verificar e gerar a versão final
```bash
npm run typecheck
npm run lint
npm run build
npm run preview
```

As pastas dist incluem as versões já compiladas. Use npm run preview para servi-las; não abra o index.html diretamente com duplo clique. Os fontes são independentes e cada app possui seu package.json e package-lock.json. node_modules foi excluída do ZIP; npm install recria as dependências. Favoritos ficam no navegador/origem; o carrinho fica apenas na sessão da página.
